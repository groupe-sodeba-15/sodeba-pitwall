/**
 * Relais Apex Timing → JSON  ·  Groupe Sodeba Racing, kart 15
 * Cloudflare Worker. Déploiement : voir README.md
 *
 * L'application interroge ce Worker toutes les 20 s et n'attend qu'une chose :
 * du JSON valide. Ce fichier ne renvoie JAMAIS d'erreur à l'application —
 * en cas d'échec il renvoie ok:false, et l'app reste en saisie manuelle.
 *
 * Variables d'environnement (onglet Settings du Worker) :
 *   TRACK  = lemans-karting        (identifiant du circuit dans l'URL Apex)
 *   KART   = 15                    (notre numéro)
 *   TEAM   = Groupe Sodeba         (secours si le numéro change d'affichage)
 */

const CORS = {
  'access-control-allow-origin': '*',
  'access-control-allow-methods': 'GET,OPTIONS',
  'cache-control': 'no-store',
  'content-type': 'application/json; charset=utf-8'
};

export default {
  async fetch(request, env) {
    if (request.method === 'OPTIONS') return new Response(null, { headers: CORS });

    const url = new URL(request.url);
    const track = env.TRACK || 'lemans-karting';
    const kart = String(env.KART || '15');
    const team = env.TEAM || 'Groupe Sodeba';

    // ---- relais Telegram (facultatif) -----------------------------------
    // Utile seulement si l'application n'arrive pas à joindre Telegram
    // directement. Renseigner alors TG_TOKEN dans les variables du Worker et
    // coller l'adresse du Worker dans le champ « relais Cloudflare » de
    // l'onglet ALERTES.
    if (url.pathname.replace(/\/$/, '').endsWith('/telegram')) {
      if (request.method !== 'POST') return json({ ok: false, reason: 'POST attendu' }, 405);
      try {
        const body = await request.json();
        const token = env.TG_TOKEN || body.token;
        if (!token) return json({ ok: false, reason: 'TG_TOKEN manquant' });
        const r = await fetch('https://api.telegram.org/bot' + token + '/sendMessage', {
          method: 'POST',
          headers: { 'content-type': 'application/json' },
          body: JSON.stringify({ chat_id: body.chat_id, text: body.text, disable_web_page_preview: true })
        });
        return json(await r.json());
      } catch (e) {
        return json({ ok: false, reason: String(e && e.message) });
      }
    }

    // ---- mode diagnostic : ?debug=1 -------------------------------------
    // À lancer une fois, pendant une séance, pour voir ce qu'Apex renvoie
    // réellement et ajuster PICK ci-dessous si besoin.
    if (url.searchParams.get('debug')) {
      const probe = await probeAll(track);
      return json({ ok: true, mode: 'debug', probe }, 200);
    }

    try {
      const grid = await loadGrid(track);
      if (!grid || !grid.rows.length) {
        return json({ ok: false, reason: 'grille vide — live probablement hors séance', at: Date.now() });
      }

      const me = findKart(grid.rows, kart, team);
      if (!me) {
        return json({ ok: false, reason: 'kart ' + kart + ' absent de la grille', seen: grid.rows.length, at: Date.now() });
      }

      const i = grid.rows.indexOf(me);
      const ahead = i > 0 ? grid.rows[i - 1] : null;
      const behind = i < grid.rows.length - 1 ? grid.rows[i + 1] : null;

      return json({
        ok: true,
        source: grid.source,
        at: Date.now(),
        kart: kart,
        position: num(me.pos) || i + 1,
        positionCategory: num(me.posCat) || null,
        laps: num(me.laps),
        lastLap: me.last || null,
        bestLap: me.best || null,
        sectors: [me.s1 || null, me.s2 || null, me.s3 || null],
        onTrack: me.onTrack || null,      // temps en piste ou temps de pit en cours
        pitTime: me.pitTime || null,
        pits: num(me.pits),
        gapLeader: me.gap || null,
        gapAhead: me.interval || null,
        gapBehind: behind ? behind.interval || null : null,
        status: statusOf(me),             // PISTE | PIT | STOP
        driver: me.driver || null,
        ahead: ahead ? { kart: ahead.kart, driver: ahead.driver, last: ahead.last } : null,
        behind: behind ? { kart: behind.kart, driver: behind.driver, last: behind.last } : null
      });
    } catch (e) {
      return json({ ok: false, reason: 'relais en erreur : ' + (e && e.message), at: Date.now() });
    }
  }
};

function json(obj, status) {
  return new Response(JSON.stringify(obj), { status: status || 200, headers: CORS });
}
function num(v) { const n = parseInt(String(v || '').replace(/[^0-9]/g, ''), 10); return isNaN(n) ? null : n; }

/* --------------------------------------------------------------------------
 * Récupération de la grille
 *
 * Apex Timing v2 alimente sa grille par WebSocket : la page HTML seule est
 * vide. On essaie donc, dans l'ordre, les points d'entrée qui renvoient de
 * la donnée en HTTP. Le premier qui répond gagne.
 * ------------------------------------------------------------------------ */
const ENDPOINTS = track => [
  `https://www.apex-timing.com/live-timing/${track}/j_grid.php`,
  `https://www.apex-timing.com/live-timing/${track}/grid.php`,
  `https://www.apex-timing.com/live-timing/${track}/data.php`,
  `https://www.apex-timing.com/live-timing/${track}/index.html`
];

async function probeAll(track) {
  const out = [];
  for (const u of ENDPOINTS(track)) {
    try {
      const r = await fetch(u, { headers: { 'user-agent': 'Mozilla/5.0 SodebaRelay' } });
      const t = await r.text();
      out.push({ url: u, status: r.status, length: t.length, head: t.slice(0, 900) });
    } catch (e) {
      out.push({ url: u, error: String(e && e.message) });
    }
  }
  return out;
}

async function loadGrid(track) {
  for (const u of ENDPOINTS(track)) {
    let text;
    try {
      const r = await fetch(u, { headers: { 'user-agent': 'Mozilla/5.0 SodebaRelay' } });
      if (!r.ok) continue;
      text = await r.text();
    } catch (e) { continue; }

    // Réponse déjà en JSON ?
    const trimmed = text.trim();
    if (trimmed.startsWith('{') || trimmed.startsWith('[')) {
      try {
        const rows = normaliseJson(JSON.parse(trimmed));
        if (rows.length) return { rows, source: u };
      } catch (e) { /* on continue */ }
    }

    const rows = parseHtmlGrid(text);
    if (rows.length) return { rows, source: u };
  }
  return null;
}

/* Correspondance entre les noms de colonnes Apex et nos champs.
 * C'est le seul endroit à ajuster si Apex change ses libellés :
 * lancez ?debug=1 et comparez. */
const PICK = {
  pos: ['rk', 'pos', 'position', 'rank'],
  posCat: ['rkcat', 'poscat', 'catrank', 'cat_rk'],
  kart: ['no', 'num', 'kart', 'number'],
  driver: ['dr', 'driver', 'team', 'name', 'pilot'],
  laps: ['laps', 'tr', 'tours', 'lap'],
  last: ['llp', 'last', 'lastlap', 'time', 'tp'],
  best: ['blp', 'best', 'bestlap'],
  s1: ['s1', 'sec1'], s2: ['s2', 'sec2'], s3: ['s3', 'sec3'],
  gap: ['gap'],
  interval: ['int', 'interval'],
  onTrack: ['otr', 'ontrack', 'on_track'],
  pitTime: ['pit', 'pittime', 'pit_time'],
  pits: ['pits', 'nbpit'],
  state: ['sta', 'status', 'state', 'st']
};

function pick(obj, field) {
  for (const k of PICK[field] || []) {
    for (const key of Object.keys(obj)) {
      if (key.toLowerCase().replace(/[^a-z0-9_]/g, '') === k) {
        const v = obj[key];
        if (v != null && String(v).trim() !== '') return String(v).trim();
      }
    }
  }
  return null;
}

function normaliseJson(data) {
  const arr = Array.isArray(data) ? data
    : (data.rows || data.grid || data.data || data.lines || []);
  if (!Array.isArray(arr)) return [];
  return arr.map(r => {
    const o = {};
    for (const f of Object.keys(PICK)) o[f] = pick(r, f);
    o.raw = r;
    return o;
  }).filter(o => o.kart || o.driver);
}

/* Grille HTML : Apex sort des lignes <tr> ou <div class="row"> dont chaque
 * cellule porte un data-type ou une classe reprenant le nom de colonne. */
function parseHtmlGrid(html) {
  const rows = [];
  const rowRe = /<(?:tr|div)[^>]*class="[^"]*\br(?:ow)?\b[^"]*"[^>]*>([\s\S]*?)<\/(?:tr|div)>/gi;
  let m;
  while ((m = rowRe.exec(html)) !== null) {
    const inner = m[1];
    const cells = {};
    const cellRe = /<(?:td|div)([^>]*)>([\s\S]*?)<\/(?:td|div)>/gi;
    let c;
    while ((c = cellRe.exec(inner)) !== null) {
      const attrs = c[1];
      const key = (attrs.match(/data-(?:type|id|col)="([^"]+)"/i) || attrs.match(/class="([^" ]+)/i) || [])[1];
      if (!key) continue;
      cells[key] = c[2].replace(/<[^>]*>/g, ' ').replace(/&nbsp;/g, ' ').replace(/\s+/g, ' ').trim();
    }
    if (!Object.keys(cells).length) continue;
    const o = {};
    for (const f of Object.keys(PICK)) o[f] = pick(cells, f);
    o.raw = cells;
    if (o.kart || o.driver) rows.push(o);
  }
  return rows;
}

function findKart(rows, kart, team) {
  const byNum = rows.find(r => String(r.kart || '').replace(/[^0-9]/g, '') === kart);
  if (byNum) return byNum;
  const t = team.toLowerCase();
  return rows.find(r => String(r.driver || '').toLowerCase().includes(t)) || null;
}

/* PISTE | PIT | STOP — l'app déclenche seule son chrono d'arrêt sur PIT. */
function statusOf(row) {
  const s = String(row.state || '').toLowerCase();
  const blob = JSON.stringify(row.raw || {}).toLowerCase();
  if (/pit_?in|st_in|\bin\b/.test(s) || /st_in\.png/.test(blob)) return 'PIT';
  if (/stop|st_stop/.test(s) || /st_stop\.png/.test(blob)) return 'STOP';
  return 'PISTE';
}
