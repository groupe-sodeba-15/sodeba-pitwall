# Comment mettre l'application en service

Trois niveaux. Commencez par le niveau 1. Vous n'aurez peut-être jamais besoin
des deux autres.

---

## Niveau 1 — Le minimum, rien à installer

C'est déjà prêt. Vous avez téléchargé un fichier qui s'appelle `index.html`.

**Attention, c'est le piège** : il existe deux fichiers d'apparence proche.

| Fichier | À utiliser ? |
| --- | --- |
| `index.html` | **OUI.** Tout est dedans, il marche seul. |
| `Sodeba Racing Pit Wall.dc.html` | NON. C'est ma version de travail. Elle a besoin d'un second fichier posé à côté d'elle, et affiche des accolades `{{ }}` partout si on l'utilise seule. |

Si vous voyez des `{{ }}` à l'écran, c'est que le mauvais fichier a été ouvert
ou mis en ligne. Reprenez `index.html`.

1. Copiez ce fichier sur le PC du stand (par exemple sur le Bureau).
2. Double-cliquez dessus. L'application s'ouvre dans le navigateur.
3. C'est tout. Elle fonctionne sans internet.

Pour l'avoir sur les téléphones : envoyez le fichier par WhatsApp ou par mail à
chaque pilote, qui l'ouvre depuis son téléphone.

**Ce que vous avez à ce niveau** : tout. Poids, lest, chrono des relais, chrono
des 85 secondes, pit stop, timeline, journal, alertes, calendrier des relais.

**Ce que vous n'avez pas** : le classement se saisit à la main (position, écarts),
et chaque appareil a ses propres données — le PC du stand ne voit pas ce que
saisit un téléphone.

Si ça vous suffit, arrêtez-vous ici.

---

## Niveau 2 — Une adresse internet à partager (GitHub)

Intérêt : au lieu d'envoyer un fichier à cinq personnes, vous donnez une adresse.
Tout le monde ouvre la même. Et quand je corrige quelque chose, tout le monde
reçoit la correction.

Cela reste gratuit et ne demande aucune connaissance technique.

### Ce qu'il faut faire

1. Allez sur `github.com`. Cliquez **Sign up**. Créez un compte (mail + mot de
   passe). C'est gratuit.
2. En haut à droite, cliquez le **+** puis **New repository**.
3. Dans *Repository name*, tapez : `sodeba-pitwall`
4. Cochez **Public**.
5. Cliquez **Create repository**.
6. Sur la page qui s'affiche, cliquez le lien **uploading an existing file**.
7. Glissez-déposez le fichier **`index.html`** (celui-là précisément, voir le
   tableau du niveau 1). Ne le renommez pas.
8. Cliquez le bouton vert **Commit changes**.
9. **Étape à ne pas sauter.** Cliquez **Add file** → **Create new file**. Dans
   le champ du nom, tapez exactement `.nojekyll` (avec le point au début).
   Laissez la page vide. Cliquez **Commit changes**.
   *À quoi ça sert* : sans ce fichier, GitHub réécrit une partie du code de
   l'application et l'écran se remplit d'accolades `{{ }}`.
10. Cliquez l'onglet **Settings** en haut, puis **Pages** dans la colonne de
    gauche.
11. Sous *Branch*, choisissez **main**, laissez `/ (root)`, cliquez **Save**.
12. Attendez deux minutes, rechargez la page. GitHub affiche votre adresse :
    `https://votre-nom.github.io/sodeba-pitwall/`

Cette adresse est celle à donner à toute l'équipe. Sur téléphone, chacun peut
l'ajouter à son écran d'accueil : elle s'ouvre alors comme une vraie application.

**Attention** : les données restent toujours propres à chaque appareil. GitHub
partage l'application, pas la course. Le PC du stand reste la référence.

---

## Niveau 3 — Le classement en automatique (Cloudflare)

Intérêt : ne plus taper la position et les écarts à la main. L'application va
les chercher toute seule sur le live timing du circuit.

À faire **avant** le week-end, tranquillement. Comptez dix minutes.

### Pourquoi c'est nécessaire

Le site du live timing refuse d'être lu par un autre site — c'est une protection
normale des navigateurs. Il faut donc un petit intermédiaire, hébergé ailleurs,
qui va lire le live timing et le repasse à l'application. C'est ce que fait le
fichier `apex-relay.js`.

### Ce qu'il faut faire

1. Allez sur `dash.cloudflare.com`. Cliquez **Sign up**. Créez un compte
   (mail + mot de passe). Gratuit, aucune carte bancaire demandée.
2. Dans la colonne de gauche, cliquez **Workers & Pages**.
3. Cliquez **Create**, puis **Create Worker**.
4. Dans le champ du nom, tapez `sodeba-apex`. Cliquez **Deploy**.
5. Cliquez **Edit code** (ou **Continue to project** puis **Edit code**).
6. Un éditeur de texte s'ouvre avec un exemple de code. **Sélectionnez tout et
   supprimez-le.**
7. Ouvrez le fichier `apex-relay.js` que je vous ai fourni, copiez tout son
   contenu, et collez-le dans l'éditeur.
8. Cliquez **Deploy** en haut à droite.
9. Revenez sur la page du Worker. Cliquez **Settings**, puis
   **Variables and Secrets**. Cliquez **Add** trois fois pour créer :

   | Nom | Valeur |
   | --- | --- |
   | `TRACK` | `lemans-karting` |
   | `KART` | `15` |
   | `TEAM` | `Groupe Sodeba` |

   Cliquez **Deploy** après avoir ajouté les trois.
10. En haut de la page du Worker, Cloudflare affiche son adresse, du genre
    `https://sodeba-apex.votre-nom.workers.dev`. Copiez-la.
11. Ouvrez l'application. Onglet **ESSENCE**. Dans l'encadré *Source live
    timing*, collez cette adresse dans le champ **URL du proxy / API**.
    Cliquez **TESTER**.

### La vérification à faire pendant les essais

Le live timing du Mans envoie ses données d'une façon que je ne peux pas
deviner à l'avance depuis mon côté : il faut la voir en fonctionnement.

**Vendredi, pendant qu'il y a des karts en piste**, ouvrez dans votre navigateur
votre adresse Cloudflare en ajoutant `?debug=1` à la fin :

```
https://sodeba-apex.votre-nom.workers.dev/?debug=1
```

Une page de texte s'affiche. Copiez-la et envoyez-la moi. Je corrige le fichier
dans la minute et vous n'aurez qu'à recoller le code (étapes 5 à 8).

Sans cette vérification, le classement restera en saisie manuelle. Tout le reste
de l'application fonctionne normalement.

---

## Niveau 4 — Les messages automatiques (Telegram)

Intérêt : plus personne n'a besoin d'appuyer. Le groupe reçoit tout seul
« Victor, relais dans 20 min », le récapitulatif horaire, le classement, les
alertes de plein, de dépassement et de sous-poids.

Gratuit, illimité, instantané. Comptez dix minutes.

### Ce qu'il faut faire

**A. Créer le groupe**

1. Chaque pilote installe **Telegram** sur son téléphone (App Store ou Play
   Store) et crée son compte avec son numéro.
2. Sur votre téléphone, créez un groupe nommé `Sodeba 15` et ajoutez les cinq
   pilotes.

**B. Créer le robot qui parlera dans le groupe**

3. Dans Telegram, cherchez le contact **@BotFather** (c'est le robot officiel de
   Telegram). Ouvrez-le, cliquez **Démarrer**.
4. Envoyez-lui : `/newbot`
5. Il demande un nom : répondez `Sodeba 15`
6. Il demande un identifiant, qui doit finir par `bot` : répondez
   `sodeba15_pitwall_bot` (si c'est pris, ajoutez des chiffres).
7. Il répond avec une longue suite de caractères du genre
   `1234567890:AAEabcdef...`. **C'est le jeton. Copiez-le.**
8. Ajoutez ce robot au groupe `Sodeba 15` comme vous ajouteriez un contact
   (cherchez le nom que vous venez de lui donner).

**C. Trouver l'identifiant du groupe**

9. Dans le groupe, écrivez n'importe quoi, par exemple `test`.
10. Dans votre navigateur, ouvrez cette adresse en remplaçant `LE_JETON` par
    votre jeton :

    ```
    https://api.telegram.org/botLE_JETON/getUpdates
    ```

11. Une page de texte s'affiche. Cherchez `"chat":{"id":-100...`. Le nombre qui
    suit `"id":`, **avec son signe moins**, est l'identifiant du groupe.
    Copiez-le.

**D. Brancher l'application**

12. Ouvrez l'application, onglet **ALERTES**, encadré *Envoi automatique
    Telegram*.
13. Collez le jeton dans le premier champ, l'identifiant du groupe dans le
    second.
14. Cliquez **ENVOYER UN TEST**. Un message doit arriver dans le groupe en une
    seconde.
15. Vérifiez que le bouton indique **ENVOI AUTOMATIQUE ACTIF**. C'est fait.

En dessous, la liste des sept messages : cliquez sur une ligne pour la couper ou
la réactiver.

### La règle à retenir

L'application doit rester **ouverte sur le PC du stand** pendant les 24 heures.
C'est elle qui connaît la course et qui envoie. Mettez l'écran en veille si vous
voulez, mais ne fermez pas le navigateur et ne mettez pas le PC en veille.

Si Telegram est bloqué par le réseau du circuit, renseignez l'adresse de votre
Worker Cloudflare dans le dernier champ de l'encadré, et ajoutez dans les
variables du Worker `TG_TOKEN` avec votre jeton. Les messages passeront par lui.

---

## Si quelque chose tombe pendant la course

- **Plus d'internet** : l'application continue. Ouvrez le fichier local du
  niveau 1 si l'adresse GitHub ne répond plus.
- **Le relais Cloudflare ne répond plus** : l'application affiche
  `ÉCHEC — MODE MANUEL` et vous saisissez la position à la main. Aucun calcul de
  poids, de lest, de relais ou de repos n'en dépend.
- **Le navigateur se ferme ou le PC redémarre** : rien n'est perdu. Les données
  sont enregistrées en continu et reviennent à la réouverture.
- **Sauvegarde** : onglet JOURNAL, bouton **SAUVEGARDE JSON**. Faites-le une
  fois par relève d'équipe. Le fichier se réimporte si besoin.

---

## Ce que je vous conseille pour ce week-end

Niveau 1 sur le PC du stand, obligatoire.
Niveau 2 si vous voulez que les pilotes aient l'appli sur leur téléphone.
Niveau 4 (Telegram) juste après : c'est celui qui change le plus la vie en
course, et il ne dépend pas d'Apex.
Niveau 3 (classement automatique) en dernier, seulement si vous avez le temps de
le tester avant samedi. Ne le découvrez pas au départ.
